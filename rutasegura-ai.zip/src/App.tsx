import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { RouteSearchForm } from './components/RouteSearchForm';
import { RouteComparisonCard } from './components/RouteComparisonCard';
import { RouteMap } from './components/RouteMap';
import { CDMXMetroGuide } from './components/CDMXMetroGuide';
import { AIAgentChat } from './components/AIAgentChat';
import { EmergencyModal } from './components/EmergencyModal';
import { KeyModal } from './components/KeyModal';
import { FacturacionModal } from './components/FacturacionModal';
import { RouteQuery, RouteAnalysisResult, RouteOption } from './types';
import { ShieldCheck, Sparkles, Navigation, AlertTriangle, PhoneCall } from 'lucide-react';

export default function App() {
  const [analysisResult, setAnalysisResult] = useState<RouteAnalysisResult | null>(null);
  const [selectedOption, setSelectedOption] = useState<RouteOption | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Modals state
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [isFacturacionOpen, setIsFacturacionOpen] = useState(false);

  // Check if Maps API key is available
  const mapsKey = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
  const hasMapsKey = Boolean(mapsKey) && mapsKey !== 'YOUR_API_KEY';

  // Trigger initial default route analysis on load (CDMX -> Acapulco)
  useEffect(() => {
    handleSearchRoute({
      origin: 'Ciudad de México',
      destination: 'Acapulco, Gro.',
      timeOfDay: 'Día (6:00 - 18:00)',
      travelMode: 'highway',
      vehicleType: 'sedan',
      preference: 'max_security'
    });
  }, []);

  const handleSearchRoute = async (query: RouteQuery) => {
    setIsLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch('/api/analyze-route', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(query)
      });

      if (!res.ok) {
        throw new Error('Error al conectar con el servidor de análisis.');
      }

      const data: RouteAnalysisResult = await res.json();
      setAnalysisResult(data);

      if (data.options && data.options.length > 0) {
        setSelectedOption(data.options[0]);
      }
    } catch (err: any) {
      console.error('Route Search Error:', err);
      setErrorMsg('No se pudo completar el análisis en tiempo real. Por favor reintente en un momento.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        onOpenEmergency={() => setIsEmergencyOpen(true)}
        onOpenKeyModal={() => setIsKeyModalOpen(true)}
        onOpenFacturacion={() => setIsFacturacionOpen(true)}
        hasMapsKey={hasMapsKey}
      />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Search Form Panel */}
        <section>
          <RouteSearchForm onSearch={handleSearchRoute} isLoading={isLoading} />
        </section>

        {/* Error Alert */}
        {errorMsg && (
          <div className="bg-red-500/10 border border-red-500/30 text-red-300 p-4 rounded-xl text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Summary Header */}
        {analysisResult && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="bg-emerald-500/10 text-emerald-300 text-xs font-bold px-3 py-1 rounded-full border border-emerald-500/20 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" /> Dictamen del Agente de IA
                </span>
                <span className="text-xs text-slate-400">
                  Ruta: <strong>{analysisResult.query.origin}</strong> ➔ <strong>{analysisResult.query.destination}</strong>
                </span>
              </div>
              <span className="text-xs text-slate-500 font-mono">
                {new Date(analysisResult.generatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} hrs
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-medium">
              {analysisResult.summary}
            </p>

            {/* Overall Advice Box */}
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-300 flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-white block mb-0.5">Recomendación General de Seguridad:</span>
                <span>{analysisResult.overallSafetyAdvice}</span>
              </div>
            </div>
          </div>
        )}

        {/* Grid Layout: Comparison Cards & Interactive Map */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Options Column (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Navigation className="w-4 h-4 text-emerald-400" />
                <span>Opciones de Ruta Comparadas ({analysisResult?.options?.length || 0})</span>
              </h2>
              <span className="text-xs text-slate-400">Haga clic en una opción para trazar en el mapa</span>
            </div>

            {isLoading ? (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-12 text-center space-y-3">
                <div className="w-8 h-8 border-3 border-emerald-400 border-t-transparent rounded-full animate-spin mx-auto" />
                <p className="text-xs text-slate-300 font-medium">
                  El agente de IA está evaluando casetas CAPUFE, índice de vigilancia y condiciones viales...
                </p>
              </div>
            ) : (
              analysisResult?.options?.map((opt) => (
                <RouteComparisonCard
                  key={opt.id}
                  option={opt}
                  isSelected={selectedOption?.id === opt.id}
                  onSelect={() => setSelectedOption(opt)}
                />
              ))
            )}
          </div>

          {/* Interactive Map Column (5 cols) */}
          <div className="lg:col-span-5 sticky top-20">
            <RouteMap
              selectedOption={selectedOption}
              hasMapsKey={hasMapsKey}
              onOpenKeyModal={() => setIsKeyModalOpen(true)}
            />
          </div>
        </div>

        {/* Specialized CDMX Metro & Urban Transport Safety Section */}
        <section>
          <CDMXMetroGuide />
        </section>

        {/* AI Agent Chat & Emergency Callout */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-7">
            <AIAgentChat
              currentQuery={analysisResult?.query || null}
              onApplyProposedRoute={(query) => {
                handleSearchRoute(query);
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>

          <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="bg-emerald-500/20 text-emerald-400 p-2 rounded-xl border border-emerald-500/30">
                <PhoneCall className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h3 className="font-bold text-white text-sm">Protocolo de Auxilio en Carreteras</h3>
                <p className="text-xs text-slate-400">Asistencia mecánica y médica 24 horas</p>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-emerald-300 block mb-1">📞 Ángeles Verdes (078)</span>
                Ofrecen auxilio mecánico gratuito, cambio de llantas y combustible de emergencia en todas las autopistas federales de México.
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-blue-300 block mb-1">🚓 Guardia Nacional (088)</span>
                Para cualquier reporte de seguridad, auxilio en caso de accidente o consulta sobre tramos carreteros activos.
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                <span className="font-bold text-amber-300 block mb-1">💳 Seguro de Usuario CAPUFE</span>
                Al conservar el ticket de pago de la caseta de cobro, cuenta con seguro automático por daños a terceros y grúa en autopistas de cuota.
              </div>
            </div>

            <button
              onClick={() => setIsEmergencyOpen(true)}
              className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold py-2.5 px-4 rounded-xl text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <span>Ver directorio completo de teléfonos de emergencia</span>
            </button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-slate-800 mt-12 py-8 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-white">RutaSegura AI</span>
            <span>— Agente Inteligente de Movilidad Vial y Transporte en México</span>
          </div>
          <p className="text-slate-500">
            Powered by Gemini 3.6 Flash & Google Maps Platform
          </p>
        </div>
      </footer>

      {/* Modals */}
      <EmergencyModal isOpen={isEmergencyOpen} onClose={() => setIsEmergencyOpen(false)} />
      <KeyModal isOpen={isKeyModalOpen} onClose={() => setIsKeyModalOpen(false)} hasMapsKey={hasMapsKey} />
      <FacturacionModal isOpen={isFacturacionOpen} onClose={() => setIsFacturacionOpen(false)} />
    </div>
  );
}
