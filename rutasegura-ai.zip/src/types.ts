export type TravelMode = 'highway' | 'metro_cdmx' | 'urban';

export type TimeOfDay = 'Día (6:00 - 18:00)' | 'Atardecer (18:00 - 21:00)' | 'Noche/Madrugada (21:00 - 6:00)';

export type VehicleType = 'sedan' | 'suv' | 'motocicleta' | 'camion' | 'transporte_publico';

export interface RouteQuery {
  origin: string;
  destination: string;
  waypoints?: string[]; // Paradas intermedias opcionales (ej: Cuernavaca, Tequisquiapan)
  timeOfDay: TimeOfDay;
  travelMode: TravelMode;
  vehicleType: VehicleType;
  preference: 'max_security' | 'cost_effective' | 'fastest';
}

export interface TollDetails {
  name: string;
  costMXN: number;
}

export interface RouteOption {
  id: string;
  name: string;
  tag: 'Recomendada (Máxima Seguridad)' | 'Económica (Libre/Cuota Parcial)' | 'Rápida / Alternativa';
  safetyScore: number; // 0 - 100
  safetyLevel: 'Excelente' | 'Alta' | 'Media' | 'Precaución';
  distanceKm: number;
  estimatedTime: string;
  estimatedTollsMXN: number;
  estimatedGasMXN: number;
  totalCostMXN: number;
  highwayType: 'Autopista de Cuota (CAPUFE)' | 'Carretera Libre' | 'Mixta' | 'Metro / Transit CDMX';
  tollsList: TollDetails[];
  keySecurityHighlights: string[];
  risksAndWarnings: string[];
  recommendedSchedule: string;
  safeRestStops: string[];
  reasoning: string;
  pathCoordinates: { lat: number; lng: number }[];
}

export interface CDMXMetroStationInfo {
  stationName: string;
  line: string;
  lineColor: string;
  safetyRating: 'Alta' | 'Media' | 'Precaución';
  nightSafetyScore: number; // 0-100
  peakHourAdvice: string;
  nightHourAdvice: string;
  femaleCarriageAvailable: boolean;
  surveillanceLevel: string;
  nearbySafeLandmarks: string[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'agent';
  text: string;
  timestamp: string;
  suggestedQuestions?: string[];
  proposedRoute?: {
    origin: string;
    destination: string;
    waypoints?: string[];
    timeOfDay?: TimeOfDay;
    summary: string;
  };
}

export interface RouteAnalysisResult {
  query: RouteQuery;
  summary: string;
  overallSafetyAdvice: string;
  options: RouteOption[];
  emergencyContacts: {
    name: string;
    number: string;
    description: string;
  }[];
  generatedAt: string;
}
