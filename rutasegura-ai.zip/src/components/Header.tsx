import React from 'react';
import { ShieldCheck, PhoneCall, Key, Sparkles, Receipt } from 'lucide-react';

interface HeaderProps {
  onOpenEmergency: () => void;
  onOpenKeyModal: () => void;
  onOpenFacturacion: () => void;
  hasMapsKey: boolean;
}

export const Header: React.FC<HeaderProps> = ({ onOpenEmergency, onOpenKeyModal, onOpenFacturacion, hasMapsKey }) => {
  return (
    <header id="main-header" className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="bg-emerald-500/20 text-emerald-400 p-2 rounded-xl border border-emerald-500/30 shadow-inner flex items-center justify-center">
            <ShieldCheck className="w-6 h-6 text-emerald-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                RutaSegura <span className="text-emerald-400">AI</span>
              </h1>
              <span className="bg-emerald-500/10 text-emerald-300 text-xs font-semibold px-2 py-0.5 rounded-full border border-emerald-500/20 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" /> Agente Vial
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Rutas verificadas, estimación de peajes y seguridad vial en México
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Facturación / RFC Button */}
          <button
            id="facturacion-rfc-btn"
            onClick={onOpenFacturacion}
            className="text-xs font-medium px-2.5 py-1.5 rounded-lg border bg-slate-800 border-slate-700 text-amber-300 hover:bg-slate-700 transition-all flex items-center gap-1.5 cursor-pointer"
            title="Facturación de casetas y registro de RFC"
          >
            <Receipt className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden md:inline">Facturación / RFC</span>
          </button>

          {/* Maps Key Status / Modal trigger */}
          <button
            id="maps-key-status-btn"
            onClick={onOpenKeyModal}
            className={`text-xs font-medium px-2.5 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer ${
              hasMapsKey
                ? 'bg-slate-800 border-emerald-500/40 text-emerald-300 hover:bg-slate-700'
                : 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
            }`}
            title="Estado de Google Maps API Key"
          >
            <Key className="w-3.5 h-3.5" />
            <span className="hidden md:inline">{hasMapsKey ? 'Google Maps Activo' : 'Clave de Mapa'}</span>
          </button>

          {/* Emergency Call Quick Button */}
          <button
            id="emergency-numbers-btn"
            onClick={onOpenEmergency}
            className="bg-red-500/15 hover:bg-red-500/25 border border-red-500/30 text-red-300 hover:text-red-200 text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <PhoneCall className="w-3.5 h-3.5 text-red-400" />
            <span>Emergencias (078 / 088)</span>
          </button>
        </div>
      </div>
    </header>
  );
};
