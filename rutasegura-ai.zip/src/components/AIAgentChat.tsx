import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, Bot, User, MapPin, ChevronRight, Navigation, ArrowRight, ShieldCheck } from 'lucide-react';
import { ChatMessage, RouteQuery } from '../types';

interface AIAgentChatProps {
  currentQuery: RouteQuery | null;
  onApplyProposedRoute?: (query: RouteQuery) => void;
}

export const AIAgentChat: React.FC<AIAgentChatProps> = ({ currentQuery, onApplyProposedRoute }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'agent',
      text: '¡Hola! Soy RutaSegura Bot, tu agente conversacional de itinerarios y seguridad vial.\n\n¿Quieres agregar una parada intermedia para comer o cargar gasolina, ajustar un destino o preguntar sobre casetas y paraderos seguros?',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedQuestions: [
        '📍 Quiero ir a Acapulco pero pasar a comer a Cuernavaca',
        '🚗 Agrega Querétaro como parada intermedia',
        '🌙 ¿Es seguro viajar de noche por esta autopista?',
        '💳 ¿Aceptan TAG IAVE en todas las casetas?'
      ]
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const queryText = textToSend || input;
    if (!queryText.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: queryText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: queryText,
          routeContext: currentQuery
        })
      });

      const data = await res.json();
      const agentMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'agent',
        text: data.reply || 'Sin respuesta del agente.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedQuestions: data.suggestedQuestions,
        proposedRoute: data.proposedRoute
      };

      setMessages((prev) => [...prev, agentMsg]);
    } catch (err) {
      console.error('Chat error:', err);
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          sender: 'agent',
          text: 'Disculpe, ocurrió un error al comunicar con el agente. Le sugiero siempre usar autopistas de cuota y marcar al 078 (Ángeles Verdes) para asistencia vial.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestedQuestions: ['¿Cuáles son los números de emergencia?', '¿Cómo llegar a Acapulco?']
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApplyRoute = (proposed: NonNullable<ChatMessage['proposedRoute']>) => {
    if (onApplyProposedRoute) {
      onApplyProposedRoute({
        origin: proposed.origin || currentQuery?.origin || 'Ciudad de México',
        destination: proposed.destination || currentQuery?.destination || 'Acapulco',
        waypoints: proposed.waypoints,
        timeOfDay: proposed.timeOfDay || currentQuery?.timeOfDay || 'Día (6:00 - 18:00)',
        travelMode: currentQuery?.travelMode || 'highway',
        vehicleType: currentQuery?.vehicleType || 'sedan',
        preference: currentQuery?.preference || 'max_security'
      });
    }
  };

  const PRESET_CHIPS = [
    '📍 Pasar a comer en Cuernavaca',
    '🛑 Paraderos y gasolineras 24h seguras',
    '💳 Casetas y recarga TAG IAVE',
    '🚇 Ruta nocturna en Metro CDMX'
  ];

  return (
    <div id="ai-agent-chat-container" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col h-[560px]">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="bg-emerald-500/20 p-2 rounded-xl border border-emerald-500/30">
            <Bot className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="font-bold text-white text-sm flex items-center gap-1.5">
              RutaSegura Bot Conversacional
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </h3>
            <p className="text-[11px] text-slate-400">Planificador de escalas, paradas intermedias y dudas de viaje</p>
          </div>
        </div>

        <span className="text-[10px] bg-emerald-500/10 text-emerald-300 font-mono px-2 py-1 rounded-md border border-emerald-500/20">
          Gemini 3.6 Flash
        </span>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto my-3 space-y-4 pr-1 text-xs">
        {messages.map((msg) => (
          <div key={msg.id} className="space-y-2">
            <div className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.sender === 'agent' && (
                <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4 text-emerald-400" />
                </div>
              )}

              <div
                className={`max-w-[88%] rounded-2xl px-4 py-3 leading-relaxed space-y-2.5 ${
                  msg.sender === 'user'
                    ? 'bg-emerald-500 text-slate-950 font-medium rounded-tr-none'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}
              >
                <p className="whitespace-pre-line">{msg.text}</p>

                {/* Proposed Route Card Banner */}
                {msg.proposedRoute && (
                  <div className="bg-slate-900 border border-emerald-500/40 rounded-xl p-3 text-xs text-slate-200 space-y-2 shadow-lg mt-2">
                    <div className="flex items-center gap-1.5 font-bold text-emerald-400">
                      <Sparkles className="w-4 h-4 text-emerald-400" />
                      <span>Nueva Propuesta de Itinerario:</span>
                    </div>

                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 font-mono text-[11px] space-y-1">
                      <div><strong className="text-slate-400">Origen:</strong> {msg.proposedRoute.origin}</div>
                      {msg.proposedRoute.waypoints && msg.proposedRoute.waypoints.length > 0 && (
                        <div className="text-amber-300">
                          <strong>📍 Escalas / Paradas:</strong> {msg.proposedRoute.waypoints.join(', ')}
                        </div>
                      )}
                      <div><strong className="text-slate-400">Destino:</strong> {msg.proposedRoute.destination}</div>
                    </div>

                    <p className="text-[11px] text-slate-300 italic">{msg.proposedRoute.summary}</p>

                    <button
                      type="button"
                      onClick={() => handleApplyRoute(msg.proposedRoute!)}
                      className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer text-[11px]"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Trazar esta ruta con escala en el mapa</span>
                    </button>
                  </div>
                )}

                <span
                  className={`block text-[10px] text-right ${
                    msg.sender === 'user' ? 'text-slate-800' : 'text-slate-500'
                  }`}
                >
                  {msg.timestamp}
                </span>
              </div>

              {msg.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-4 h-4 text-slate-300" />
                </div>
              )}
            </div>

            {/* Smart Suggested Questions Chips */}
            {msg.sender === 'agent' && msg.suggestedQuestions && msg.suggestedQuestions.length > 0 && (
              <div className="pl-9 flex flex-wrap gap-1.5">
                {msg.suggestedQuestions.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(q)}
                    disabled={isLoading}
                    className="text-[10px] bg-slate-800/80 hover:bg-slate-700 text-emerald-300 px-2.5 py-1 rounded-lg border border-slate-700 hover:border-emerald-500/40 transition-all flex items-center gap-1 text-left"
                  >
                    <span>{q}</span>
                    <ChevronRight className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="flex gap-2.5 items-center text-slate-400">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
              <Bot className="w-4 h-4 text-emerald-400 animate-spin" />
            </div>
            <span className="italic text-[11px]">RutaSegura Bot está analizando tu consulta...</span>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Preset Suggestions Chips Bar */}
      <div className="py-2 flex flex-wrap gap-1.5 border-t border-slate-800">
        {PRESET_CHIPS.map((q, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(q)}
            disabled={isLoading}
            className="text-[10px] bg-slate-950 hover:bg-slate-800 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-800 transition-all flex items-center gap-1"
          >
            <span>{q}</span>
            <ChevronRight className="w-2.5 h-2.5 text-slate-500" />
          </button>
        ))}
      </div>

      {/* Input Area */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }}
        className="flex gap-2 pt-2"
      >
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ej: Quiero pasar por Cuernavaca a comer o preguntar sobre casetas..."
          className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-all"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2.5 rounded-xl transition-all disabled:opacity-50 cursor-pointer flex items-center justify-center gap-1"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
