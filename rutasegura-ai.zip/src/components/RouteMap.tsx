import React, { useEffect, useRef } from 'react';
import { APIProvider, Map, AdvancedMarker, Pin, useMap, useMapsLibrary } from '@vis.gl/react-google-maps';
import { RouteOption } from '../types';
import { MapPin, Navigation, ShieldCheck, Key, AlertTriangle, Layers, Info } from 'lucide-react';

interface RouteMapProps {
  selectedOption: RouteOption | null;
  hasMapsKey: boolean;
  onOpenKeyModal: () => void;
}

// Inner component for rendering polyline when Google Maps API is active
function MapRoutePolyline({ option }: { option: RouteOption }) {
  const map = useMap();
  const routesLib = useMapsLibrary('routes');
  const polylineRef = useRef<google.maps.Polyline | null>(null);

  useEffect(() => {
    if (!map || !option) return;

    // Draw native Polyline using coordinates
    if (polylineRef.current) {
      polylineRef.current.setMap(null);
    }

    if (option.pathCoordinates && option.pathCoordinates.length > 0) {
      const path = option.pathCoordinates.map((pt) => ({ lat: pt.lat, lng: pt.lng }));

      const polyline = new google.maps.Polyline({
        path,
        geodesic: true,
        strokeColor: option.safetyScore >= 90 ? '#10B981' : '#F59E0B',
        strokeOpacity: 0.9,
        strokeWeight: 6,
      });

      polyline.setMap(map);
      polylineRef.current = polyline;

      // Fit bounds
      const bounds = new google.maps.LatLngBounds();
      path.forEach((pt) => bounds.extend(pt));
      map.fitBounds(bounds, 50);
    }

    return () => {
      if (polylineRef.current) polylineRef.current.setMap(null);
    };
  }, [map, option]);

  return null;
}

export const RouteMap: React.FC<RouteMapProps> = ({ selectedOption, hasMapsKey, onOpenKeyModal }) => {
  const API_KEY = process.env.GOOGLE_MAPS_PLATFORM_KEY || '';
  const canUseNativeMap = hasMapsKey && Boolean(API_KEY);

  // Center calculation or default CDMX
  const center = selectedOption?.pathCoordinates?.[0] || { lat: 19.4326, lng: -99.1332 };

  return (
    <div id="route-map-container" className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col h-[520px] relative">
      {/* Map Header Overlay */}
      <div className="bg-slate-950/90 backdrop-blur-md px-4 py-3 border-b border-slate-800 z-10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Navigation className="w-4 h-4 text-emerald-400" />
          <span className="text-xs font-bold text-white uppercase tracking-wider">
            {selectedOption ? `Visualizador de Ruta: ${selectedOption.name}` : 'Mapa Interactivo de Ruta'}
          </span>
        </div>
        {selectedOption && (
          <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold border ${
            selectedOption.safetyScore >= 90
              ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
              : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
          }`}>
            Seguridad: {selectedOption.safetyScore}/100
          </span>
        )}
      </div>

      {/* Native Google Map or Interactive Canvas Visualizer */}
      <div className="flex-1 relative w-full h-full bg-slate-950 flex items-center justify-center">
        {canUseNativeMap ? (
          <APIProvider apiKey={API_KEY} version="weekly">
            <Map
              defaultCenter={center}
              defaultZoom={7}
              mapId="DEMO_MAP_ID"
              internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
              style={{ width: '100%', height: '100%' }}
            >
              {selectedOption && <MapRoutePolyline option={selectedOption} />}
              {selectedOption?.pathCoordinates?.map((coord, idx) => (
                <AdvancedMarker key={idx} position={coord}>
                  <Pin
                    background={idx === 0 ? '#10B981' : idx === selectedOption.pathCoordinates.length - 1 ? '#EF4444' : '#F59E0B'}
                    glyphColor="#FFF"
                  />
                </AdvancedMarker>
              ))}
            </Map>
          </APIProvider>
        ) : (
          /* High quality custom Route Canvas fallback when Google Maps API key is pending */
          <div className="w-full h-full relative bg-slate-950 p-6 flex flex-col items-center justify-between overflow-hidden">
            {/* Grid Pattern Overlay */}
            <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none" />

            {/* Custom SVG Route Path Animation */}
            <div className="w-full max-w-xl h-64 relative my-auto flex items-center justify-center">
              <svg className="w-full h-full" viewBox="0 0 500 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Background route curve */}
                <path
                  d="M 40 160 Q 150 40 250 120 T 460 50"
                  stroke="#1e293b"
                  strokeWidth="12"
                  strokeLinecap="round"
                />
                {/* Glowing active safety polyline */}
                <path
                  d="M 40 160 Q 150 40 250 120 T 460 50"
                  stroke={selectedOption && selectedOption.safetyScore >= 90 ? '#10B981' : '#F59E0B'}
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeDasharray="8 4"
                  className="animate-pulse"
                />

                {/* Waypoint Markers */}
                {/* Start */}
                <circle cx="40" cy="160" r="9" fill="#10B981" />
                <circle cx="40" cy="160" r="14" stroke="#10B981" strokeWidth="2" strokeOpacity="0.4" />
                <text x="40" y="190" textAnchor="middle" fill="#94A3B8" fontSize="11" fontWeight="bold">
                  Origen
                </text>

                {/* Toll Checkpoint 1 */}
                <circle cx="180" cy="80" r="6" fill="#F59E0B" />
                <text x="180" y="65" textAnchor="middle" fill="#FCD34D" fontSize="10">
                  Caseta 1
                </text>

                {/* Toll Checkpoint 2 */}
                <circle cx="310" cy="120" r="6" fill="#F59E0B" />
                <text x="310" y="140" textAnchor="middle" fill="#FCD34D" fontSize="10">
                  Caseta 2
                </text>

                {/* End */}
                <circle cx="460" cy="50" r="9" fill="#EF4444" />
                <circle cx="460" cy="50" r="14" stroke="#EF4444" strokeWidth="2" strokeOpacity="0.4" />
                <text x="460" y="30" textAnchor="middle" fill="#94A3B8" fontSize="11" fontWeight="bold">
                  Destino
                </text>
              </svg>
            </div>

            {/* Info overlay box */}
            {selectedOption ? (
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 max-w-lg w-full text-xs text-slate-300 flex items-center justify-between z-10 shadow-lg">
                <div>
                  <span className="block font-bold text-white">{selectedOption.name}</span>
                  <span className="text-slate-400">
                    {selectedOption.distanceKm} km • Peajes: ${selectedOption.estimatedTollsMXN} MXN
                  </span>
                </div>
                <button
                  onClick={onOpenKeyModal}
                  className="bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 px-2.5 py-1.5 rounded-lg text-[11px] font-medium flex items-center gap-1 transition-all"
                >
                  <Key className="w-3 h-3" /> Activación Mapa Vía Google
                </button>
              </div>
            ) : (
              <div className="text-xs text-slate-400 text-center z-10">
                Seleccione una ruta en los resultados para visualizar las casetas y tramos de seguridad.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer Banner for Google Maps status */}
      <div className="bg-slate-950 px-4 py-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
        <span className="flex items-center gap-1.5">
          <Info className="w-3.5 h-3.5 text-blue-400" />
          Rutas analizadas con datos satelitales y vigilancia CAPUFE / C5 CDMX.
        </span>
        <button
          onClick={onOpenKeyModal}
          className="text-emerald-400 hover:underline font-medium flex items-center gap-1"
        >
          <Key className="w-3 h-3" /> Configurar Google Maps Key
        </button>
      </div>
    </div>
  );
};
