import React, { useState } from 'react';
import { ShieldCheck, ShieldAlert, DollarSign, Clock, MapPin, ChevronDown, ChevronUp, AlertCircle, CheckCircle2, Navigation, Coffee, Info } from 'lucide-react';
import { RouteOption } from '../types';

interface RouteComparisonCardProps {
  option: RouteOption;
  isSelected: boolean;
  onSelect: () => void;
}

export const RouteComparisonCard: React.FC<RouteComparisonCardProps> = ({ option, isSelected, onSelect }) => {
  const [showTolls, setShowTolls] = useState(false);

  // Safety Score Color
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
    if (score >= 75) return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
    return 'text-red-400 bg-red-500/10 border-red-500/30';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 90) return 'Seguridad Máxima';
    if (score >= 75) return 'Seguridad Media';
    return 'Alta Precaución';
  };

  return (
    <div
      onClick={onSelect}
      className={`bg-slate-900 border rounded-2xl p-5 transition-all cursor-pointer relative overflow-hidden ${
        isSelected
          ? 'border-emerald-500 shadow-xl shadow-emerald-500/10 ring-1 ring-emerald-500'
          : 'border-slate-800 hover:border-slate-700 hover:bg-slate-850'
      }`}
    >
      {/* Top Tag & Selection Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
        <div className="flex items-center gap-2">
          <span className={`text-xs font-semibold px-3 py-1 rounded-full border ${
            option.tag.includes('Recomendada')
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
              : 'bg-blue-500/20 text-blue-300 border-blue-500/30'
          }`}>
            {option.tag}
          </span>
          <span className="text-xs text-slate-400 font-medium">
            {option.highwayType}
          </span>
        </div>

        {/* Safety Score Meter */}
        <div className={`flex items-center gap-2 px-3 py-1 rounded-xl border ${getScoreColor(option.safetyScore)} font-bold text-sm`}>
          <ShieldCheck className="w-4 h-4" />
          <span>{option.safetyScore} / 100 ({getScoreBadge(option.safetyScore)})</span>
        </div>
      </div>

      {/* Route Name & Distance / Time Header */}
      <div className="mb-4">
        <h3 className="text-lg font-bold text-white mb-1 flex items-center justify-between">
          <span>{option.name}</span>
        </h3>
        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-300">
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Tiempo estimado: <strong className="text-white">{option.estimatedTime}</strong></span>
          </div>
          <div className="flex items-center gap-1">
            <Navigation className="w-3.5 h-3.5 text-blue-400" />
            <span>Distancia: <strong className="text-white">{option.distanceKm} km</strong></span>
          </div>
        </div>
      </div>

      {/* Financial Cost Breakdown Box */}
      <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3.5 mb-4 grid grid-cols-3 gap-2 text-center">
        <div>
          <span className="block text-[11px] text-slate-400 uppercase font-medium">Casetas (Peaje)</span>
          <span className="text-sm font-bold text-amber-300">${option.estimatedTollsMXN} MXN</span>
        </div>
        <div>
          <span className="block text-[11px] text-slate-400 uppercase font-medium">Combustible Est.</span>
          <span className="text-sm font-bold text-blue-300">${option.estimatedGasMXN} MXN</span>
        </div>
        <div className="border-l border-slate-800 pl-2">
          <span className="block text-[11px] text-slate-400 uppercase font-medium">Costo Total</span>
          <span className="text-base font-extrabold text-emerald-400">${option.totalCostMXN} MXN</span>
        </div>
      </div>

      {/* AI Reasoning / Overview */}
      <div className="mb-4 bg-slate-800/40 border border-slate-800 rounded-xl p-3 text-xs text-slate-300 leading-relaxed">
        <p className="flex items-start gap-2">
          <Info className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <span><strong>Evaluación del Agente:</strong> {option.reasoning}</span>
        </p>
      </div>

      {/* Security Highlights & Warnings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4 text-xs">
        {/* Highlights */}
        <div className="bg-emerald-950/20 border border-emerald-500/20 rounded-xl p-3">
          <h4 className="font-semibold text-emerald-300 mb-2 flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Garantías de Seguridad
          </h4>
          <ul className="space-y-1.5 text-slate-300">
            {option.keySecurityHighlights.map((item, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-emerald-400 font-bold">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Risks */}
        <div className="bg-amber-950/20 border border-amber-500/20 rounded-xl p-3">
          <h4 className="font-semibold text-amber-300 mb-2 flex items-center gap-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
            Precauciones en el Trayecto
          </h4>
          <ul className="space-y-1.5 text-slate-300">
            {option.risksAndWarnings.map((item, idx) => (
              <li key={idx} className="flex items-start gap-1.5">
                <span className="text-amber-400 font-bold">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Recommended Rest Stops / Safe Paraderos */}
      {option.safeRestStops && option.safeRestStops.length > 0 && (
        <div className="mb-4 bg-slate-950/50 border border-slate-800 rounded-xl p-3 text-xs">
          <span className="font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
            <Coffee className="w-3.5 h-3.5 text-amber-400" />
            Paraderos y Gasolineras Iluminadas Recomendadas:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {option.safeRestStops.map((stop, idx) => (
              <span key={idx} className="bg-slate-800 text-slate-200 px-2.5 py-1 rounded-lg text-[11px] border border-slate-700">
                {stop}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Expandable Tolls List */}
      {option.tollsList && option.tollsList.length > 0 && (
        <div className="border-t border-slate-800 pt-3">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setShowTolls(!showTolls);
            }}
            className="text-xs text-slate-400 hover:text-emerald-400 font-medium flex items-center justify-between w-full transition-colors"
          >
            <span>Desglose de Casetas de Cobro ({option.tollsList.length})</span>
            {showTolls ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showTolls && (
            <div className="mt-2.5 bg-slate-950 rounded-xl p-3 space-y-1.5 text-xs text-slate-300 border border-slate-800">
              {option.tollsList.map((toll, idx) => (
                <div key={idx} className="flex justify-between items-center py-1 border-b border-slate-900 last:border-0">
                  <span className="text-slate-300">{toll.name}</span>
                  <span className="font-bold text-amber-300">${toll.costMXN} MXN</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
