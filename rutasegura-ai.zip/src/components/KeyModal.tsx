import React from 'react';
import { Key, X, CheckCircle2, ExternalLink, ShieldCheck } from 'lucide-react';

interface KeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  hasMapsKey: boolean;
}

export const KeyModal: React.FC<KeyModalProps> = ({ isOpen, onClose, hasMapsKey }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative space-y-5">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="bg-emerald-500/20 text-emerald-400 p-2.5 rounded-xl border border-emerald-500/30">
            <Key className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Google Maps Platform Key</h2>
            <p className="text-xs text-slate-400">Estado de integración para mapas satelitales vectoriales</p>
          </div>
        </div>

        {hasMapsKey ? (
          <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-4 text-xs text-emerald-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-emerald-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Google Maps Activo Correctamente</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              La variable de entorno <code className="text-emerald-300 bg-slate-900 px-1 py-0.5 rounded">GOOGLE_MAPS_PLATFORM_KEY</code> está configurada. Las rutas y mapas satelitales renderizarán con calidad vectorial.
            </p>
          </div>
        ) : (
          <div className="space-y-4 text-xs text-slate-300">
            <p className="leading-relaxed">
              La aplicación incluye un renderizador interactivo integrado. Para activar mapas satelitales vectoriales con Google Maps Platform, siga estos pasos:
            </p>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5 text-[11px]">
              <div className="flex items-start gap-2">
                <span className="bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded text-xs">1</span>
                <div>
                  Obtenga su clave en la{' '}
                  <a
                    href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais"
                    target="_blank"
                    rel="noreferrer"
                    className="text-emerald-400 underline font-semibold inline-flex items-center gap-1"
                  >
                    Consola de Google Cloud <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded text-xs">2</span>
                <div>
                  Abra el menú <strong>Configuración ⚙️</strong> (esquina superior derecha) ➔ <strong>Secrets</strong>.
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded text-xs">3</span>
                <div>
                  Nombre de la secret: <code className="text-amber-300 font-mono">GOOGLE_MAPS_PLATFORM_KEY</code>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <span className="bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded text-xs">4</span>
                <div>Pegue su clave de API y presione <strong>Enter</strong>. La aplicación se actualizará automáticamente.</div>
              </div>
            </div>
          </div>
        )}

        <button
          onClick={onClose}
          className="w-full bg-slate-800 hover:bg-slate-700 text-white font-semibold py-2.5 rounded-xl transition-all text-xs"
        >
          Entendido
        </button>
      </div>
    </div>
  );
};
