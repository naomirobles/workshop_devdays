import React, { useState } from 'react';
import { Navigation, Car, Bus, Moon, Sun, Sunset, Shield, DollarSign, Clock, MapPin, Sparkles, AlertTriangle, Truck, Bike } from 'lucide-react';
import { RouteQuery, TimeOfDay, TravelMode, VehicleType } from '../types';

interface RouteSearchFormProps {
  onSearch: (query: RouteQuery) => void;
  isLoading: boolean;
}

export const RouteSearchForm: React.FC<RouteSearchFormProps> = ({ onSearch, isLoading }) => {
  const [travelMode, setTravelMode] = useState<TravelMode>('highway');
  const [origin, setOrigin] = useState('Ciudad de México');
  const [destination, setDestination] = useState('Acapulco, Gro.');
  const [waypoints, setWaypoints] = useState<string[]>([]);
  const [timeOfDay, setTimeOfDay] = useState<TimeOfDay>('Día (6:00 - 18:00)');
  const [vehicleType, setVehicleType] = useState<VehicleType>('sedan');
  const [preference, setPreference] = useState<'max_security' | 'cost_effective' | 'fastest'>('max_security');
  const [isLocating, setIsLocating] = useState(false);

  const isNight = timeOfDay.includes('Noche');

  const handleAddWaypoint = () => {
    if (waypoints.length < 3) {
      setWaypoints([...waypoints, '']);
    }
  };

  const handleUpdateWaypoint = (index: number, val: string) => {
    const next = [...waypoints];
    next[index] = val;
    setWaypoints(next);
  };

  const handleRemoveWaypoint = (index: number) => {
    setWaypoints(waypoints.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!origin.trim() || !destination.trim()) return;
    const cleanWaypoints = waypoints.map(w => w.trim()).filter(Boolean);
    onSearch({
      origin,
      destination,
      waypoints: cleanWaypoints.length > 0 ? cleanWaypoints : undefined,
      timeOfDay,
      travelMode,
      vehicleType,
      preference
    });
  };

  const handleApplyPreset = (orig: string, dest: string, mode: TravelMode = 'highway', presetWaypoints?: string[]) => {
    setOrigin(orig);
    setDestination(dest);
    setTravelMode(mode);
    setWaypoints(presetWaypoints || []);
    onSearch({
      origin: orig,
      destination: dest,
      waypoints: presetWaypoints,
      timeOfDay,
      travelMode: mode,
      vehicleType,
      preference
    });
  };

  const handleGeolocate = () => {
    if (!navigator.geolocation) {
      alert('La geolocalización no está soportada por su navegador.');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        setOrigin(`Ubicación actual (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)})`);
      },
      (err) => {
        setIsLocating(false);
        console.warn('Geolocation error:', err);
        setOrigin('Ciudad de México (Centro)');
      }
    );
  };

  return (
    <div id="route-search-container" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl relative overflow-hidden">
      {/* Background Subtle Accent */}
      <div className="absolute -top-24 -right-24 w-60 h-60 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-60 h-60 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Mode Selector Tabs */}
      <div className="flex border-b border-slate-800 mb-6 pb-2 gap-2">
        <button
          type="button"
          id="mode-tab-highway"
          onClick={() => {
            setTravelMode('highway');
            setOrigin('Ciudad de México');
            setDestination('Acapulco, Gro.');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm transition-all ${
            travelMode === 'highway'
              ? 'bg-emerald-500 text-slate-950 font-semibold shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Car className="w-4 h-4" />
          <span>Carreteras y Autopistas</span>
        </button>

        <button
          type="button"
          id="mode-tab-metro"
          onClick={() => {
            setTravelMode('metro_cdmx');
            setOrigin('Metro Bellas Artes');
            setDestination('Metro Universidad (L2 / L3)');
          }}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm transition-all ${
            travelMode === 'metro_cdmx'
              ? 'bg-emerald-500 text-slate-950 font-semibold shadow-md shadow-emerald-500/20'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
          }`}
        >
          <Bus className="w-4 h-4" />
          <span>Metro y Transporte CDMX</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Origin & Destination inputs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Origin */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Punto de Origen</span>
              <button
                type="button"
                onClick={handleGeolocate}
                disabled={isLocating}
                className="text-[11px] text-emerald-400 hover:underline flex items-center gap-1 font-normal lowercase"
              >
                <MapPin className="w-3 h-3" />
                {isLocating ? 'Obteniendo...' : 'usar mi ubicación'}
              </button>
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-emerald-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="input-origin"
                type="text"
                value={origin}
                onChange={(e) => setOrigin(e.target.value)}
                placeholder="Ej: Ciudad de México, Satélite, Monterrey..."
                className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                required
              />
            </div>
          </div>

          {/* Destination */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Punto de Destino
            </label>
            <div className="relative">
              <Navigation className="w-4 h-4 text-blue-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="input-destination"
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="Ej: Acapulco, Querétaro, Puebla, Cancún..."
                className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                required
              />
            </div>
          </div>
        </div>

        {/* Optional Waypoints (Paradas intermedias) */}
        {waypoints.length > 0 && (
          <div className="space-y-2 bg-slate-950/60 p-3.5 rounded-xl border border-slate-800">
            <label className="text-xs font-semibold text-amber-400 uppercase tracking-wider block">
              📍 Paradas Intermedias ({waypoints.length}/3)
            </label>
            {waypoints.map((wp, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <span className="text-xs font-mono text-slate-400 w-5 text-center">{idx + 1}.</span>
                <input
                  type="text"
                  value={wp}
                  onChange={(e) => handleUpdateWaypoint(idx, e.target.value)}
                  placeholder="Ej: Cuernavaca, Tequisquiapan, San Miguel de Allende..."
                  className="flex-1 bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => handleRemoveWaypoint(idx)}
                  className="text-xs text-slate-400 hover:text-red-400 p-1 rounded transition-all"
                  title="Eliminar parada"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between pt-1">
          {waypoints.length < 3 && (
            <button
              type="button"
              onClick={handleAddWaypoint}
              className="text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1.5 transition-all"
            >
              <span>+ Agregar parada intermedia o escala</span>
            </button>
          )}
        </div>

        {/* Filters: Time of Day, Vehicle Type, Preference */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Time of Day */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1">
              <span>Horario de Salida</span>
              {isNight && <AlertTriangle className="w-3 h-3 text-amber-400 inline" />}
            </label>
            <div className="relative">
              <select
                id="select-time-of-day"
                value={timeOfDay}
                onChange={(e) => setTimeOfDay(e.target.value as TimeOfDay)}
                className={`w-full bg-slate-950/80 border rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none transition-all ${
                  isNight
                    ? 'border-amber-500/50 text-amber-200'
                    : 'border-slate-700/80 focus:border-emerald-500'
                }`}
              >
                <option value="Día (6:00 - 18:00)">☀️ Día (6:00 - 18:00) - Recomendado</option>
                <option value="Atardecer (18:00 - 21:00)">🌅 Atardecer (18:00 - 21:00)</option>
                <option value="Noche/Madrugada (21:00 - 6:00)">🌙 Noche / Madrugada (21:00 - 6:00)</option>
              </select>
            </div>
          </div>

          {/* Vehicle Type */}
          {travelMode === 'highway' ? (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Tipo de Vehículo
              </label>
              <select
                id="select-vehicle-type"
                value={vehicleType}
                onChange={(e) => setVehicleType(e.target.value as VehicleType)}
                className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 transition-all"
              >
                <option value="sedan">🚗 Automóvil Sedán / Compacto</option>
                <option value="suv">SUV / Camioneta Familiar</option>
                <option value="motocicleta">🏍️ Motocicleta</option>
                <option value="camion">🚛 Tráiler / Camión de Carga</option>
              </select>
            </div>
          ) : (
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Modalidad CDMX
              </label>
              <div className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs text-slate-300">
                🚇 Metro, Metrobús y M1
              </div>
            </div>
          )}

          {/* Preference */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Prioridad de Ruta
            </label>
            <select
              id="select-preference"
              value={preference}
              onChange={(e) => setPreference(e.target.value as any)}
              className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500 transition-all"
            >
              <option value="max_security">🛡️ Máxima Seguridad (Vigilancia & Cuota)</option>
              <option value="cost_effective">💰 Balance Costo / Peaje</option>
              <option value="fastest">⚡ Vía Más Rápida</option>
            </select>
          </div>
        </div>

        {/* Night Warning Callout */}
        {isNight && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 text-xs text-amber-200 flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-amber-300">Alerta de Seguridad Nocturna:</span> En trayectos nocturnos, el agente de IA priorizará automáticamente autopistas de cuota monitoreadas con patrullaje constante y paraderos seguros iluminados.
            </div>
          </div>
        )}

        {/* Quick Route Presets */}
        <div className="space-y-2">
          <span className="text-xs font-medium text-slate-400">Rutas populares en México:</span>
          <div className="flex flex-wrap gap-2">
            {travelMode === 'highway' ? (
              <>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('Ciudad de México', 'Acapulco, Gro.')}
                  className="bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition-all"
                >
                  CDMX ➔ Acapulco (Cuota 95D)
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('Ciudad de México', 'Querétaro, Qro.')}
                  className="bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition-all"
                >
                  CDMX ➔ Querétaro (Cuota 57D)
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('Ciudad de México', 'Puebla, Pue.')}
                  className="bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition-all"
                >
                  CDMX ➔ Puebla (150D)
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('Guadalajara', 'Puerto Vallarta')}
                  className="bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition-all"
                >
                  Guadalajara ➔ Vallarta
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('Monterrey', 'Nuevo Laredo')}
                  className="bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition-all"
                >
                  Monterrey ➔ Nuevo Laredo
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('Metro Bellas Artes', 'Metro Universidad', 'metro_cdmx')}
                  className="bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition-all"
                >
                  Bellas Artes ➔ Universidad (L2/L3)
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('Metro Chabacano', 'Metro Pantitlán', 'metro_cdmx')}
                  className="bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition-all"
                >
                  Chabacano ➔ Pantitlán (L9/L1)
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyPreset('Metro Insurgentes', 'Metro Indios Verdes', 'metro_cdmx')}
                  className="bg-slate-800/80 hover:bg-slate-700 text-xs text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 transition-all"
                >
                  Insurgentes ➔ Indios Verdes
                </button>
              </>
            )}
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          id="btn-submit-search"
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold py-3.5 px-6 rounded-xl shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50 cursor-pointer text-sm"
        >
          {isLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              <span>Agente de IA analizando seguridad y peajes en tiempo real...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              <span>Analizar Rutas Seguras y Costos con IA</span>
            </>
          )}
        </button>
      </form>
    </div>
  );
};
