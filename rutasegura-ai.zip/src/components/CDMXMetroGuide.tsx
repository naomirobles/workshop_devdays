import React, { useState } from 'react';
import { Bus, ShieldCheck, Moon, Heart, AlertTriangle, Eye, CheckCircle2, Clock, Search, MapPin } from 'lucide-react';
import { CDMXMetroStationInfo } from '../types';

const CDMX_STATIONS_DATA: CDMXMetroStationInfo[] = [
  {
    stationName: "Bellas Artes",
    line: "Línea 2 (Azul) / Línea 8 (Verde)",
    lineColor: "#0072CE",
    safetyRating: "Alta",
    nightSafetyScore: 92,
    peakHourAdvice: "Uso continuo de torniquetes monitoreados. Excelente afluencia y presencia policial.",
    nightHourAdvice: "Se recomienda abordar en los primeros 3 vagones cerca de la cabina del conductor. Salida segura por Alameda Central.",
    femaleCarriageAvailable: true,
    surveillanceLevel: "C5 Activo + Policía Auxiliar 24h",
    nearbySafeLandmarks: ["Alameda Central", "Palacio de Bellas Artes", "Módulo SSC"]
  },
  {
    stationName: "Chabacano",
    line: "Línea 2 (Azul) / Línea 8 / Línea 9 (Café)",
    lineColor: "#804000",
    safetyRating: "Alta",
    nightSafetyScore: 89,
    peakHourAdvice: "Nodo central de transbordo con andenes amplios. Mantenga pertenencias al frente en horas pico.",
    nightHourAdvice: "Transbordos iluminados con cámaras. Evitar pasillos secundarios solitarios pasadas las 22:30.",
    femaleCarriageAvailable: true,
    surveillanceLevel: "C5 Activo + Monitoreo por Videovigilancia",
    nearbySafeLandmarks: ["Calzada de Tlalpan", "Punto de Control Policial"]
  },
  {
    stationName: "Balderas",
    line: "Línea 1 (Rosa) / Línea 3 (Verde Olivo)",
    lineColor: "#E4007D",
    safetyRating: "Alta",
    nightSafetyScore: 94,
    peakHourAdvice: "Transbordo con flujo ágil. Estación remodelada con nueva iluminación LED en Línea 1.",
    nightHourAdvice: "Instalaciones completamente renovadas con excelente visión nocturna y patrullaje fijo.",
    femaleCarriageAvailable: true,
    surveillanceLevel: "Seguridad Reforzada Línea 1 Renovada",
    nearbySafeLandmarks: ["Biblioteca de México", "Avenida Arcos de Belén"]
  },
  {
    stationName: "Universidad",
    line: "Línea 3 (Verde Olivo)",
    lineColor: "#999900",
    safetyRating: "Alta",
    nightSafetyScore: 87,
    peakHourAdvice: "Terminal con alto flujo estudiantil. Andenes amplios y vigilados.",
    nightHourAdvice: "Usar salidas hacia el paradero iluminado de Pumasbus / Taxis autorizados.",
    femaleCarriageAvailable: true,
    surveillanceLevel: "Vigilancia UNAM + Policía de la CDMX",
    nearbySafeLandmarks: ["Ciudad Universitaria", "Base de Taxis Seguros UNAM"]
  },
  {
    stationName: "Insurgentes",
    line: "Línea 1 (Rosa)",
    lineColor: "#E4007D",
    safetyRating: "Alta",
    nightSafetyScore: 91,
    peakHourAdvice: "Conexión directa con Metrobús Línea 1 sobre superficie. Muy iluminada.",
    nightHourAdvice: "Salida hacia la glorieta iluminada con presencia comercial activa hasta noche.",
    femaleCarriageAvailable: true,
    surveillanceLevel: "C5 + Policía de Turismo CDMX",
    nearbySafeLandmarks: ["Glorieta de Insurgentes", "Zona Rosa (Comercial)"]
  },
  {
    stationName: "Pantitlán",
    line: "Línea 1 / L5 / L9 / LA",
    lineColor: "#804000",
    safetyRating: "Precaución",
    nightSafetyScore: 74,
    peakHourAdvice: "Extrema afluencia. Se aconseja preparar tarjeta MI previamente y no usar el teléfono en andenes abarrotados.",
    nightHourAdvice: "En horario nocturno, prefiera transbordos directos por Metrobús sobre superficie o vagones frontales.",
    femaleCarriageAvailable: true,
    surveillanceLevel: "Monitoreo Especial por Afluencia",
    nearbySafeLandmarks: ["Paradero M1 Bicentenario", "Módulo de Seguridad"]
  },
  {
    stationName: "Zapata",
    line: "Línea 3 / Línea 12 (Dorada)",
    lineColor: "#C19A6B",
    safetyRating: "Alta",
    nightSafetyScore: 93,
    peakHourAdvice: "Conexión accesible y limpia. Excelente señalización y visibilidad.",
    nightHourAdvice: "Ruta nocturna muy segura con vigilancia continua en escaleras eléctricas y andenes.",
    femaleCarriageAvailable: true,
    surveillanceLevel: "C5 + Seguridad Privada STC",
    nearbySafeLandmarks: ["Plaza Universidad", "Avenida Universidad"]
  }
];

export const CDMXMetroGuide: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'stations' | 'night_tips'>('stations');

  const filteredStations = CDMX_STATIONS_DATA.filter(
    (s) =>
      s.stationName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.line.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="cdmx-metro-guide" className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
      {/* Section Title */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Bus className="w-5 h-5 text-emerald-400" />
            <span>Guía de Seguridad en Metro y Transporte CDMX</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Evaluación de estaciones, transbordos monitoreados y recomendaciones nocturnas
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex gap-2">
          <button
            onClick={() => setActiveTab('stations')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'stations'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            Ranking de Estaciones
          </button>
          <button
            onClick={() => setActiveTab('night_tips')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'night_tips'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            Protocolo Nocturno
          </button>
        </div>
      </div>

      {activeTab === 'stations' ? (
        <div className="space-y-4">
          {/* Station Filter Search */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar estación (Ej: Bellas Artes, Balderas, Universidad, Línea 2)..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-all"
            />
          </div>

          {/* Stations List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredStations.map((st, idx) => (
              <div
                key={idx}
                className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-all space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-white text-sm flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Estación {st.stationName}</span>
                    </h3>
                    <span className="text-[11px] text-slate-400 font-medium">{st.line}</span>
                  </div>

                  {/* Night Score Badge */}
                  <div className="text-right">
                    <span className="text-xs font-extrabold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-lg">
                      {st.nightSafetyScore}/100 Nocturno
                    </span>
                  </div>
                </div>

                {/* Advice details */}
                <div className="space-y-2 text-xs">
                  <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                    <span className="font-semibold text-slate-300 block mb-0.5 flex items-center gap-1">
                      <Moon className="w-3 h-3 text-amber-400" />
                      Recomendación Nocturna:
                    </span>
                    <p className="text-slate-400 text-[11px] leading-relaxed">{st.nightHourAdvice}</p>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 text-emerald-300">
                      <Eye className="w-3 h-3 text-emerald-400" />
                      {st.surveillanceLevel}
                    </span>

                    {st.femaleCarriageAvailable && (
                      <span className="bg-pink-500/10 text-pink-300 border border-pink-500/20 px-2 py-0.5 rounded-md font-medium flex items-center gap-1">
                        <Heart className="w-3 h-3 text-pink-400" /> Vagón Exclusivo Activo
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Protocolo Nocturno / Tips tab */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
            <h3 className="font-bold text-emerald-300 flex items-center gap-2 text-sm">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              1. Abordaje en Primeros Vagones
            </h3>
            <p className="text-slate-300 leading-relaxed">
              En horarios de menor afluencia (después de las 21:00 hrs), posiciónese en el andén cerca de los dos primeros vagones contiguos a la fábrica de control / cabina del conductor. Ahí se concentra la iluminación y la supervisión del operador del tren.
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
            <h3 className="font-bold text-pink-300 flex items-center gap-2 text-sm">
              <Heart className="w-4 h-4 text-pink-400" />
              2. Vagones Exclusivos para Mujeres y Menores
            </h3>
            <p className="text-slate-300 leading-relaxed">
              En todas las líneas del Metro y Metrobús operan vagones exclusivos delimitados al frente de los trenes. Cuentan con presencia permanente de la Policía Auxiliar en andenes.
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
            <h3 className="font-bold text-amber-300 flex items-center gap-2 text-sm">
              <Moon className="w-4 h-4 text-amber-400" />
              3. Alternativa Nochebús (Superficie)
            </h3>
            <p className="text-slate-300 leading-relaxed">
              Si su trayecto es pasadas las 00:00 hrs (cierre del Metro), utilice las rutas de Nochebús del Servicio de Transportes Eléctricos (STE) e RTP sobre avenidas principales como Insurgentes, Reforma, Periférico y Paseo de la Reforma.
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
            <h3 className="font-bold text-blue-300 flex items-center gap-2 text-sm">
              <CheckCircle2 className="w-4 h-4 text-blue-400" />
              4. Puntos de Botón de Pánico C5
            </h3>
            <p className="text-slate-300 leading-relaxed">
              Tanto dentro de las instalaciones del STC Metro como en los tótems de las calles exteriores, active los botones de auxilio C5. Tienen enlace directo con la policía de la CDMX y cámara de video en tiempo real.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
