import React from 'react';
import { PhoneCall, X, ShieldAlert, Wrench, Siren, Car, AlertTriangle } from 'lucide-react';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const EMERGENCY_LIST = [
    {
      title: "Ángeles Verdes (Auxilio Vial Gratuito)",
      number: "078",
      icon: Wrench,
      color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30",
      desc: "Asistencia mecánica básica, cambio de llantas, paso de corriente, arrastre y orientación turística en carreteras federales."
    },
    {
      title: "Guardia Nacional (División Carreteras)",
      number: "088",
      icon: Siren,
      color: "text-blue-400 bg-blue-500/10 border-blue-500/30",
      desc: "Vigilancia, reportes de incidentes de seguridad, robo, bloqueos o accidentes en autopistas y vías federales."
    },
    {
      title: "CAPUFE (Atención e Información de Casetas)",
      number: "074",
      icon: Car,
      color: "text-amber-400 bg-amber-500/10 border-amber-500/30",
      desc: "Atención médica, grúa y reporte de condiciones del camino en autopistas operadas por CAPUFE."
    },
    {
      title: "Emergencias Nacionales C5 / 911",
      number: "911",
      icon: ShieldAlert,
      color: "text-red-400 bg-red-500/10 border-red-500/30",
      desc: "Enlace inmediato con policía, ambulancias de urgencia y bomberos en todo el territorio mexicano."
    },
    {
      title: "Locatel / CDMX C5",
      number: "55 5658 1111",
      icon: PhoneCall,
      color: "text-purple-400 bg-purple-500/10 border-purple-500/30",
      desc: "Asistencia e información sobre transporte, incidencias en Metro y soporte vial en la Ciudad de México."
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative space-y-5">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="bg-red-500/20 text-red-400 p-2.5 rounded-xl border border-red-500/30">
            <PhoneCall className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Directorio de Emergencia Vial México</h2>
            <p className="text-xs text-slate-400">Marcación directa gratuita desde cualquier teléfono celular</p>
          </div>
        </div>

        {/* Numbers List */}
        <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1 text-xs">
          {EMERGENCY_LIST.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div key={idx} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-start gap-3">
                <div className={`p-2 rounded-xl border ${item.color} shrink-0`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h3 className="font-bold text-white">{item.title}</h3>
                    <a
                      href={`tel:${item.number.replace(/\s/g, '')}`}
                      className="bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-extrabold px-3 py-1 rounded-lg text-sm flex items-center gap-1 transition-all"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>{item.number}</span>
                    </a>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">{item.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Checklist */}
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 text-[11px] text-amber-200 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong>Consejo en caso de avería en carretera:</strong> Encienda las luces intermitentes de emergencia, permanezca dentro del vehículo si la zona es solitaria o colóquese detrás de las barreras de protección de la carretera con chaleco reflejante.
          </div>
        </div>
      </div>
    </div>
  );
};
