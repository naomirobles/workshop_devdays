import React, { useState } from 'react';
import { Receipt, X, FileText, CheckCircle2, ExternalLink, Building2, CreditCard, HelpCircle } from 'lucide-react';

interface FacturacionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FacturacionModal: React.FC<FacturacionModalProps> = ({ isOpen, onClose }) => {
  const [rfc, setRfc] = useState('');
  const [razonSocial, setRazonSocial] = useState('');
  const [cfdi, setCfdi] = useState('G03 - Gastos en general');
  const [savedSuccess, setSavedSuccess] = useState(false);

  if (!isOpen) return null;

  const FACTURACION_PORTALS = [
    {
      name: "CAPUFE (Facturación Electrónica Oficial)",
      url: "https://facturacion.capufe.gob.mx/",
      desc: "Facture sus tickets de casetas operadas por Caminos y Puentes Federales dentro de los primeros 60 días.",
      tag: "Red Federal"
    },
    {
      name: "PASE / TAG Facturación",
      url: "https://www.pase.com.mx/",
      desc: "Descargue facturas automáticas de todos los peajes cobrados a su TAG PASE asociando su RFC.",
      tag: "TAG Automático"
    },
    {
      name: "Televía Facturación",
      url: "https://www.televia.com.mx/",
      desc: "Consulte el historial de cruces por caseta y emita sus comprobantes fiscales CFDI 4.0.",
      tag: "TAG Automático"
    },
    {
      name: "Circuito Exterior Mexiquense (CEM)",
      url: "https://www.facturacioncem.com.mx/",
      desc: "Portal de facturación para casetas del Estado de México y Circuito Exterior.",
      tag: "Edomex"
    },
    {
      name: "Autopista México - Toluca (PINFRA)",
      url: "https://facturacionpinfra.com.mx/",
      desc: "Facturación para concesiones de PINFRA (México-Toluca, Vía Corta, etc.).",
      tag: "Concesionada"
    }
  ];

  const handleSaveRfc = (e: React.FormEvent) => {
    e.preventDefault();
    if (!rfc.trim()) return;
    localStorage.setItem('user_rfc', rfc.toUpperCase().trim());
    localStorage.setItem('user_razon_social', razonSocial.trim());
    localStorage.setItem('user_cfdi', cfdi);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative space-y-5">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-3">
          <div className="bg-amber-500/20 text-amber-400 p-2.5 rounded-xl border border-amber-500/30">
            <Receipt className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Facturación de Casetas y RFC</h2>
            <p className="text-xs text-slate-400">Guía de comprobantes fiscales CFDI 4.0 para peajes de carreteras</p>
          </div>
        </div>

        {/* RFC Quick Save Form */}
        <form onSubmit={handleSaveRfc} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-emerald-400" />
              Guardar tu RFC localmente para compras/peajes
            </span>
            {savedSuccess && (
              <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> ¡RFC Guardado!
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">RFC (Persona Física o Moral)</label>
              <input
                type="text"
                value={rfc}
                onChange={(e) => setRfc(e.target.value.toUpperCase())}
                placeholder="Ej: XAXX010101000 / ABC120304XYZ"
                maxLength={13}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono uppercase"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">Razón Social o Nombre</label>
              <input
                type="text"
                value={razonSocial}
                onChange={(e) => setRazonSocial(e.target.value)}
                placeholder="Ej: Juan Pérez Morales S.A."
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <span className="text-[11px] text-slate-500">Uso de CFDI: G03 - Gastos en general</span>
            <button
              type="submit"
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-3.5 py-1.5 rounded-lg text-xs transition-all cursor-pointer"
            >
              Guardar Datos Fiscales
            </button>
          </div>
        </form>

        {/* Portal Direct Links */}
        <div className="space-y-2.5">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Portales Directos de Facturación de Peaje en México:
          </h3>
          <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 text-xs">
            {FACTURACION_PORTALS.map((portal, idx) => (
              <div key={idx} className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-start justify-between gap-3">
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{portal.name}</span>
                    <span className="bg-slate-800 text-amber-300 text-[10px] px-2 py-0.5 rounded font-mono">
                      {portal.tag}
                    </span>
                  </div>
                  <p className="text-slate-400 text-[11px] leading-relaxed">{portal.desc}</p>
                </div>
                <a
                  href={portal.url}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 font-semibold px-2.5 py-1.5 rounded-lg text-[11px] flex items-center gap-1 transition-all shrink-0 mt-1"
                >
                  <span>Portal</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            ))}
          </div>
        </div>

        {/* Guidance Notice */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-3 text-[11px] text-slate-400 space-y-1">
          <div className="font-bold text-slate-300 flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
            ¿Cómo facturar un ticket de caseta con tu RFC?
          </div>
          <p className="leading-relaxed">
            Conserve el boleto de peaje físico. En él encontrará el código de ticket (o Kiosco ID), la hora y el importe. Ingrese al portal de la caseta correspondiente (CAPUFE o concesionaria) e introduzca su RFC para recibir la factura XML y PDF en su correo registrado.
          </p>
        </div>
      </div>
    </div>
  );
};
