import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// Emergency Contacts constant for Mexico
const MEXICO_EMERGENCY_CONTACTS = [
  { name: "Ángeles Verdes (Auxilio Vial)", number: "078", description: "Asistencia mecánica, médica y orientación turística en carreteras federales." },
  { name: "Guardia Nacional (Carreteras)", number: "088", description: "Reportes de seguridad, vigilancia e incidentes en autopistas." },
  { name: "Emergencias Nacionales", number: "911", description: "Policía, ambulancias y bomberos a nivel nacional." },
  { name: "CAPUFE (Casetas y Auxilio)", number: "074", description: "Atención en autopistas de cuota administradas por CAPUFE." },
  { name: "Locatel CDMX", number: "55 5658 1111", description: "Atención ciudadana y reportes en Ciudad de México." },
];

// Highway route presets / fallback generator for high reliability
function getFallbackRouteAnalysis(origin: string, destination: string, timeOfDay: string, travelMode: string, vehicleType: string, waypoints?: string[]) {
  const origLower = origin.toLowerCase();
  const destLower = destination.toLowerCase();
  const isNight = timeOfDay.toLowerCase().includes("noche") || timeOfDay.toLowerCase().includes("madrugada");

  // Default fallback calculation tailored for Mexican Roads & Transit
  let option1Name = `Autopista de Cuota (Vía Directa Segura)`;
  let option2Name = `Ruta Mixta (Cuota Parcial / Carretera Libre)`;
  let option3Name = `Vía Secundaria / Alternativa`;

  let costTolls = 480;
  let costGas = 420;
  let dist = 380;
  let timeStr = "4h 15 min";

  if (origLower.includes("acapulco") || destLower.includes("acapulco")) {
    option1Name = "Autopista del Sol (Cuota 95D)";
    option2Name = "Carretera Federal 95 (Libre)";
    costTolls = 845;
    costGas = 580;
    dist = 378;
    timeStr = "4h 30 min";
  } else if (origLower.includes("querétaro") || destLower.includes("queretaro")) {
    option1Name = "Autopista México - Querétaro (Cuota 57D)";
    option2Name = "Circuito Exterior Mexiquense + Cuota 57D";
    costTolls = 360;
    costGas = 320;
    dist = 218;
    timeStr = "2h 45 min";
  } else if (origLower.includes("puebla") || destLower.includes("puebla")) {
    option1Name = "Autopista México - Puebla (Cuota 150D)";
    option2Name = "Carretera Federal 190 (Libre)";
    costTolls = 210;
    costGas = 240;
    dist = 135;
    timeStr = "1h 50 min";
  } else if (travelMode === "metro_cdmx" || origLower.includes("metro") || origLower.includes("cdmx")) {
    return {
      query: { origin, destination, waypoints, timeOfDay: timeOfDay as any, travelMode: travelMode as any, vehicleType: vehicleType as any, preference: "max_security" as const },
      summary: `Análisis de seguridad para trayecto en transporte público / Metro en CDMX para horario: ${timeOfDay}.`,
      overallSafetyAdvice: isNight
        ? "Durante horarios nocturnos o de menor flujo, priorice abordar los primeros vagones cercanos a la cabina del conductor y utilice estaciones con mayor iluminación y monitoreo C5."
        : "Horario de alto flujo con monitoreo activo. Mantenga sus pertenencias al frente y utilice los transbordos iluminados.",
      options: [
        {
          id: "m1",
          name: "Ruta Directa por Metro L1 / L2 + Transbordo en Estación Monitoreada",
          tag: "Recomendada (Máxima Seguridad)",
          safetyScore: isNight ? 88 : 95,
          safetyLevel: isNight ? "Alta" : "Excelente",
          distanceKm: 14,
          estimatedTime: "32 min",
          estimatedTollsMXN: 5,
          estimatedGasMXN: 0,
          totalCostMXN: 5,
          highwayType: "Metro / Transit CDMX",
          tollsList: [{ name: "Tarifa Metro CDMX", costMXN: 5 }],
          keySecurityHighlights: [
            "Estaciones con presencia continua de Policía Auxiliar y cámaras C5.",
            "Vagones exclusivos para mujeres y menores activos.",
            "Zona de abordaje iluminada cerca de cabina del tren."
          ],
          risksAndWarnings: isNight
            ? ["Evitar pasillos secundarios oscuros en transbordos largos después de las 22:00.", "Tener la tarjeta MI lista antes de ingresar."]
            : ["Afluencia en horas pico en estaciones de intercambio."],
          recommendedSchedule: "Tránsito sugerido antes de las 23:00 hrs.",
          safeRestStops: ["Módulos de información SSC", "Puntos de auxilio con botón de pánico en andenes"],
          reasoning: "Ofrece mayor presencia policial, andenes con cámaras de videovigilancia activa y menor tiempo de espera en andenes.",
          pathCoordinates: [
            { lat: 19.4326, lng: -99.1332 },
            { lat: 19.427, lng: -99.1378 },
            { lat: 19.418, lng: -99.1415 }
          ]
        },
        {
          id: "m2",
          name: "Ruta Alternativa por Metrobús (Superficie Monitoreada)",
          tag: "Económica (Libre/Cuota Parcial)",
          safetyScore: 91,
          safetyLevel: "Excelente",
          distanceKm: 16,
          estimatedTime: "40 min",
          estimatedTollsMXN: 6,
          estimatedGasMXN: 0,
          totalCostMXN: 6,
          highwayType: "Metro / Transit CDMX",
          tollsList: [{ name: "Tarifa Metrobús CDMX", costMXN: 6 }],
          keySecurityHighlights: [
            "Navegación sobre avenidas principales con iluminación constante.",
            "Cámaras a bordo conectadas al C5 en cada unidad.",
            "Estaciones cerradas con validadores de seguridad."
          ],
          risksAndWarnings: ["Posible tráfico vehicular en hora pico."],
          recommendedSchedule: "Servicio disponible con buena vigilancia hasta las 00:00 hrs.",
          safeRestStops: ["Estaciones con personal de seguridad privada y CCTV"],
          reasoning: "Excelente alternativa sobre superficie para evitar túneles o transbordos subterráneos en horarios nocturnos.",
          pathCoordinates: [
            { lat: 19.4326, lng: -99.1332 },
            { lat: 19.422, lng: -99.155 },
            { lat: 19.412, lng: -99.165 }
          ]
        }
      ],
      emergencyContacts: MEXICO_EMERGENCY_CONTACTS,
      generatedAt: new Date().toISOString()
    };
  }

  // General Highway Fallback
  return {
    query: { origin, destination, waypoints, timeOfDay: timeOfDay as any, travelMode: travelMode as any, vehicleType: vehicleType as any, preference: "max_security" as const },
    summary: `Evaluación de seguridad vial y costos para el tramo ${origin} ➔ ${destination}.`,
    overallSafetyAdvice: isNight
      ? "ADVERTENCIA DE VIAJE NOCTURNO: Se recomienda encarecidamente utilizar exclusivamente autopistas de cuota (CAPUFE), hacer paradas solo en paraderos oficiales/gasolineras iluminadas con tiendas 24h y mantener el TAG IAVE cargado."
      : "Condiciones de visibilidad óptimas. Circule por autopistas de cuota para contar con seguro de usuario CAPUFE y asistencia en carretera 078.",
    options: [
      {
        id: "opt-1",
        name: option1Name,
        tag: "Recomendada (Máxima Seguridad)",
        safetyScore: isNight ? 91 : 97,
        safetyLevel: "Excelente",
        distanceKm: dist,
        estimatedTime: timeStr,
        estimatedTollsMXN: costTolls,
        estimatedGasMXN: costGas,
        totalCostMXN: costTolls + costGas,
        highwayType: "Autopista de Cuota (CAPUFE)",
        tollsList: [
          { name: "Caseta Principal de Salida", costMXN: Math.round(costTolls * 0.45) },
          { name: "Caseta Intermedia de Tramo", costMXN: Math.round(costTolls * 0.35) },
          { name: "Caseta de Llegada", costMXN: Math.round(costTolls * 0.20) }
        ],
        keySecurityHighlights: [
          "Seguro de viajero CAPUFE incluido al pagar peaje.",
          "Monitoreo frecuente de la Guardia Nacional División Carreteras.",
          "Patrullaje continuo de Ángeles Verdes (078) para asistencia mecánica.",
          "Paraderos turísticos oficiales iluminados y gasolineras con tienda de conveniencia."
        ],
        risksAndWarnings: isNight
          ? ["Reducir velocidad en tramos de niebla o reparaciones.", "Evitar detenerse en acotamientos no iluminados."]
          : ["Aumento de tráfico en horas pico de salida."],
        recommendedSchedule: "Salida sugerida entre 06:00 y 10:00 hrs para máxima tranquilidad.",
        safeRestStops: ["Paradero Oficial CAPUFE km 85 (Restaurante + Gasolinera + Vigilancia)", "Plaza de Cobro con sanitarios y módulo de auxilio vial"],
        reasoning: "Es la ruta más segura, mejor mantenida y vigilada. Cuenta con soporte de grúa y ambulancia CAPUFE ante cualquier imprevisto.",
        pathCoordinates: [
          { lat: 19.4326, lng: -99.1332 },
          { lat: 19.2500, lng: -99.1000 },
          { lat: 18.9200, lng: -99.2300 },
          { lat: 16.8531, lng: -99.8237 }
        ]
      },
      {
        id: "opt-2",
        name: option2Name,
        tag: "Económica (Libre/Cuota Parcial)",
        safetyScore: isNight ? 72 : 83,
        safetyLevel: isNight ? "Precaución" : "Media",
        distanceKm: dist + 25,
        estimatedTime: "5h 10 min",
        estimatedTollsMXN: Math.round(costTolls * 0.4),
        estimatedGasMXN: costGas + 60,
        totalCostMXN: Math.round(costTolls * 0.4) + costGas + 60,
        highwayType: "Mixta",
        tollsList: [
          { name: "Caseta de Enlace Urbano", costMXN: Math.round(costTolls * 0.4) }
        ],
        keySecurityHighlights: [
          "Ahorro significativo en el costo total de casetas.",
          "Atraviesa poblaciones locales con acceso a servicios comerciales."
        ],
        risksAndWarnings: [
          "Mayor presencia de topes, semáforos y cruces peatonales.",
          "Menor iluminación nocturna en tramos rurales libres.",
          "No incluye cobertura automática del seguro CAPUFE en tramos libres."
        ],
        recommendedSchedule: "Recomendado realizar el recorrido únicamente durante el día (07:00 - 17:00 hrs).",
        safeRestStops: ["Gasolineras grandes en entradas a cabeceras municipales"],
        reasoning: "Buena opción de presupuesto de día, pero requiere mayor atención en la conducción por incorporaciones urbanas y topes.",
        pathCoordinates: [
          { lat: 19.4326, lng: -99.1332 },
          { lat: 19.1800, lng: -99.0500 },
          { lat: 18.8000, lng: -99.1500 },
          { lat: 16.8531, lng: -99.8237 }
        ]
      }
    ],
    emergencyContacts: MEXICO_EMERGENCY_CONTACTS,
    generatedAt: new Date().toISOString()
  };
}

// Route Analysis API Endpoint
app.post("/api/analyze-route", async (req, res) => {
  try {
    const { origin, destination, waypoints, timeOfDay, travelMode, vehicleType, preference } = req.body;

    if (!origin || !destination) {
      return res.status(400).json({ error: "Debe especificar origen y destino." });
    }

    const ai = getGeminiClient();

    if (!ai) {
      // Return structured fallback when API key is not configured
      const fallback = getFallbackRouteAnalysis(origin, destination, timeOfDay || "Día", travelMode || "highway", vehicleType || "sedan");
      if (waypoints && waypoints.length > 0) {
        fallback.query.waypoints = waypoints;
        fallback.summary += ` Incluye paradas intermedias en: ${waypoints.join(', ')}.`;
      }
      return res.json(fallback);
    }

    const waypointsText = waypoints && waypoints.length > 0 ? `- Paradas intermedias: ${waypoints.join(', ')}` : '';

    const prompt = `
Eres RutaSegura AI, el agente experto líder en seguridad vial, carreteras en México, casetas de cobro, costos de combustible y transporte público (incluyendo el Metro de CDMX).
Analiza el siguiente trayecto solicitado por el usuario:
- Origen: ${origin}
${waypointsText}
- Destino: ${destination}
- Horario de viaje: ${timeOfDay || 'Día'}
- Modo de transporte: ${travelMode || 'highway'}
- Tipo de vehículo: ${vehicleType || 'sedan'}
- Preferencia del usuario: ${preference || 'max_security'}

Genera una respuesta en formato JSON estrictamente estructurada con la siguiente interfaz:
{
  "summary": "Resumen conciso y profesional del análisis de ruta e itinerario con paradas.",
  "overallSafetyAdvice": "Consejo directo sobre la seguridad del trayecto según el horario y las carreteras/transporte a usar.",
  "options": [
    {
      "id": "opt-1",
      "name": "Nombre claro de la ruta (Ej: Autopista de Cuota 95D con escala en Cuernavaca)",
      "tag": "Recomendada (Máxima Seguridad)" | "Económica (Libre/Cuota Parcial)" | "Rápida / Alternativa",
      "safetyScore": 95, // Número entre 0 y 100
      "safetyLevel": "Excelente" | "Alta" | "Media" | "Precaución",
      "distanceKm": 350,
      "estimatedTime": "3h 45 min",
      "estimatedTollsMXN": 450,
      "estimatedGasMXN": 380,
      "totalCostMXN": 830,
      "highwayType": "Autopista de Cuota (CAPUFE)" | "Carretera Libre" | "Mixta" | "Metro / Transit CDMX",
      "tollsList": [
        { "name": "Nombre de caseta", "costMXN": 120 }
      ],
      "keySecurityHighlights": [
        "Punto de seguridad 1",
        "Punto de seguridad 2"
      ],
      "risksAndWarnings": [
        "Riesgo o precaución 1"
      ],
      "recommendedSchedule": "Horario óptimo de viaje",
      "safeRestStops": ["Paradero seguro 1", "Gasolinera recomendada 2"],
      "reasoning": "Explicación detallada de por qué esta ruta es buena o qué considerar al incluir las paradas intermedias.",
      "pathCoordinates": [
        { "lat": 19.4326, "lng": -99.1332 },
        { "lat": 18.92, "lng": -99.23 },
        { "lat": 16.85, "lng": -99.82 }
      ]
    }
  ]
}

REGLAS DE ORO:
1. Asegúrate de incluir estimaciones realistas de casetas en pesos mexicanos (MXN) basadas en tarifas actuales de CAPUFE / Autopistas Concesionadas.
2. Si el usuario solicita paradas intermedias, calcula el tiempo total sumando las paradas y verifica la seguridad de los accesos a cada poblado o punto intermedio.
3. Evalúa objetivamente el nivel de seguridad criminal y vial, especialmente si el horario es nocturno o de madrugada.
4. Devuelve al menos 2 opciones de ruta para comparar (ej: Vía de Cuota vs Vía Libre/Mixta).
5. Devuelve SOLO JSON válido, sin bloques de código extraños.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.2
      }
    });

    const text = response.text || "";
    let data;
    try {
      data = JSON.parse(text);
    } catch (parseErr) {
      console.warn("Failed to parse Gemini JSON output, using fallback:", parseErr);
      data = getFallbackRouteAnalysis(origin, destination, timeOfDay || "Día", travelMode || "highway", vehicleType || "sedan");
    }

    // Attach query & emergency contacts
    data.query = { origin, destination, waypoints, timeOfDay, travelMode, vehicleType, preference };
    data.emergencyContacts = MEXICO_EMERGENCY_CONTACTS;
    data.generatedAt = new Date().toISOString();

    res.json(data);
  } catch (err: any) {
    console.error("Error in /api/analyze-route:", err);
    // Fallback on error
    const fallback = getFallbackRouteAnalysis(req.body?.origin || "CDMX", req.body?.destination || "Acapulco", req.body?.timeOfDay || "Día", req.body?.travelMode || "highway", req.body?.vehicleType || "sedan");
    res.json(fallback);
  }
});

// AI Chatbot Assistant for conversational route planning & follow-ups
app.post("/api/chat", async (req, res) => {
  try {
    const { message, routeContext } = req.body;

    if (!message) {
      return res.status(400).json({ error: "El mensaje no puede estar vacío." });
    }

    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        reply: "RutaSegura Bot: Para utilizar las funciones avanzadas conversacionales de planificación de rutas y paradas intermedias, configure la clave GEMINI_API_KEY en los Secrets. Mientras tanto, le sugiero siempre viajar de día por carreteras de cuota y guardar el número 078 de Ángeles Verdes.",
        suggestedQuestions: [
          "¿Cuáles son las carreteras de cuota más seguras?",
          "¿Aceptan TAG IAVE en todas las casetas?",
          "¿Cómo pedir ayuda al 078?"
        ]
      });
    }

    const contextInfo = routeContext
      ? `[Ruta actual en pantalla: Origen=${routeContext.origin}, Destino=${routeContext.destination}, Paradas=${routeContext.waypoints ? routeContext.waypoints.join(', ') : 'Ninguna'}, Horario=${routeContext.timeOfDay}]`
      : '[Sin ruta activa aún]';

    const prompt = `
Eres 'RutaSegura Bot', el agente inteligente de IA especializado en planificación conversacional de rutas, paradas intermedias, seguridad vial y costos en México.

Contexto del usuario:
${contextInfo}

Mensaje recibido del usuario:
"${message}"

INSTRUCCIONES DE RESPUESTA:
Responde de forma amable, clara y estructurada. Si el usuario desea:
1. Agregar paradas intermedias ("quiero pasar antes por Cuernavaca", "pasa por Querétaro"), cambiar el destino u origen, propone la nueva configuración de ruta de forma atractiva.
2. Realizar preguntas de seguridad, horarios nocturnos, peajes o Metro CDMX, responde con datos verídicos y recomendaciones prácticas.
3. Plantea siempre 2 a 3 preguntas de seguimiento inteligentes que el usuario pueda presionar rápidamente.

Devuelve la respuesta en formato JSON con la siguiente estructura:
{
  "reply": "Texto completo formateado en Markdown de tu respuesta profesional e interactiva.",
  "suggestedQuestions": [
    "Pregunta de seguimiento corta 1",
    "Pregunta de seguimiento corta 2",
    "Pregunta de seguimiento corta 3"
  ],
  "proposedRoute": { // Opcional, incluir SOLO SI el usuario pide o menciona cambiar origen, destino o agregar/quitar paradas intermedias
    "origin": "Ciudad de México",
    "destination": "Acapulco",
    "waypoints": ["Cuernavaca"],
    "timeOfDay": "Día (6:00 - 18:00)",
    "summary": "Nueva ruta sugerida pasando por Cuernavaca para comer con máxima seguridad de cuota."
  }
}

Retorna ÚNICAMENTE JSON válido.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.3
      }
    });

    const text = response.text || "";
    let data;
    try {
      data = JSON.parse(text);
    } catch (parseErr) {
      console.warn("Failed to parse Gemini Chat JSON output:", parseErr);
      data = {
        reply: text || "RutaSegura Bot: He procesado tu solicitud. Recuerda mantener tus luces encendidas y usar autopistas de cuota.",
        suggestedQuestions: [
          "¿Hay casetas en esta ruta?",
          "¿Dónde están las gasolineras iluminadas?",
          "¿Cómo está el patrullaje de la Guardia Nacional?"
        ]
      };
    }

    res.json(data);
  } catch (err: any) {
    console.error("Error in /api/chat:", err);
    res.json({
      reply: "RutaSegura Bot: Tuve un inconveniente momentáneo al conectar. Como sugerencia general de seguridad: mantén la distancia de seguridad y utiliza siempre autopistas de cuota (CAPUFE).",
      suggestedQuestions: [
        "¿Cuáles son los números de emergencia?",
        "¿Cuál es el mejor horario para viajar?"
      ]
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
